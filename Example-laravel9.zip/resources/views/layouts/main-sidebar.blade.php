<div class="container-fluid">
    <div class="row">
        <!-- Left Sidebar start-->
        <div class="side-menu-fixed">
            <div class="scrollbar side-menu-bg">
                <ul class="nav navbar-nav side-menu" id="sidebarnav">
                    <!-- menu item Dashboard-->
                    <li>
                        <a href="{{url('/dashboard')}}">
                            <div class="pull-left"><i class="ti-home"></i><span class="right-nav-text" style="font-size:20px;">الرئسية </span>
                            </div>
                            <div class="pull-right"></div>
                            <div class="clearfix"></div>
                        </a>

                    </li>
                    <!-- menu title -->
                    </li>
                    <li class="mt-10 mb-10 text-muted pl-4 font-medium menu-title">لوحة الاستاذ   </li>

                    <!-- menu item Authentication-->
                 


                    <li>
                        <a href="{{url('books')}}">
                            <div class="pull-left"><i class="ti-id-badge"></i><span class="right-nav-text" style="font-size: 18px;">الكتب </span></div>
                            <div class="clearfix"></div>
                        </a>
                    </li>

                  

                    
                </ul>
                </li>
                </ul>
            </div>
        </div>

        <!-- Left Sidebar End-->

        <!--=================================