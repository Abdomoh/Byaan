
<?php $__env->startSection('content'); ?>

<section id="contact" class="contact">
    <div class="container">
        <br><br>
        <div class="row justify-content-center" data-aos="fade-up">

            <div class="col-lg-10">
                <?php echo $__env->make('message._message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="info-wrap">
                    <div class="row">
                        <div class="col-lg-12 info">
                            <i class="fa fa-user"></i>
                            <h4 class="text-center"> تسجيل دخول</h4>

                        </div>

                    </div>
                </div>

            </div>

        </div>

        <div class="row mt-5 justify-content-center" data-aos="fade-up">

            <div class="col-lg-10">
                <div class="info-wrap">
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group mt-3">
                            <input type="email" class="form-control" name="email" id="subject" placeholder="email" required>
                        </div>

                        <div class="form-group mt-3">
                            <input type="password" class="form-control" name="password" id="password" placeholder="password" required>
                        </div>
                        <br>
                        <div class="text-center text-white"><button type="submit" name="submit" class="btn btn-warning btn-block text-white">تسجيل دخول</button></div>
                    </form>

                    <p class="text-center"> - او -</p>

                    <div class="text-center text-white"><a href="<?php echo e(route('register')); ?>"><button type="submit" name="submit" class="btn btn-dark btn-block text-white"> انشاء حساب</button></a></div>
                </div>
            </div>
        </div>

    </div>
</section><!-- End Contact Section -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\freelancer project\Example-laravel9\resources\views/users/login.blade.php ENDPATH**/ ?>