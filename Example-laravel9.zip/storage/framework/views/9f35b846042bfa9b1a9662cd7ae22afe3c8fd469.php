<html dir="lrt">
<?php if(Session()->has('success')): ?>

<div class="row">
    <div class="col-sm-12">
        <div class="alert alert-success" role="alert">
        <?php echo e(Session::get('success')); ?>

        </div>
    </div>
</div>
<?php endif; ?>

<?php if(Session()->has('login')): ?>

<div class="row">
    <div class="col-sm-12">
        <div class="alert alert-success" role="alert">
        <?php echo e(Session::get('login')); ?>

        </div>
    </div>
</div>
<?php endif; ?>



<?php if(Session::has('error')): ?>
<script type="text/javascript">
   toastr.options = {
      "closeButton": true,
      "progressBar": true
   }
   toastr.error("<?php echo e(session('error')); ?>");
</script>
<?php endif; ?>




<?php if(session()->has('success')): ?>

<script type="text/javascript">
   window.onload = function() {
      notif({
         msg: " تم الادخال بنجاح ",
         type: "success",
         time: "5"
      })
   }
</script>
<?php endif; ?>


<?php if(session()->has('info')): ?>
<script type="text/javascript">
   window.onload = function() {
      notif({
         msg: " تم التعديل بنجاح ",
         type: "info",
         time: "5"
      })
   }
</script>
<?php endif; ?>

<?php if(count($errors) > 0): ?>
<div class="row">
   <div class="col-sm-12">
      <div class="alert alert-danger" role="alert">
         <strong>رسالة خطا </strong>
         <ul>

            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </ul>
      </div>
   </div>
</div>
<?php endif; ?>

</html><?php /**PATH D:\freelancer project\Example-laravel9\resources\views/message/_message.blade.php ENDPATH**/ ?>