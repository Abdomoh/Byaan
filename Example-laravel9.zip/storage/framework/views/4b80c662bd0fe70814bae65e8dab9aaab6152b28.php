<?php $__env->startSection('content'); ?>


<!-- ======= Hero Section ======= -->
<section id="hero" dir="ltr" style="">
  <div id="heroCarousel" data-bs-interval="5000" class="carousel slide carousel-fade" data-bs-ride="carousel" style="background: rgba( 57, 55, 77, 0.75 );">

    <div class="carousel-inner" role="listbox">



      <!-- Slide 2 -->


      <!-- Slide 3 -->
      <div class="carousel-item active" style="  background: linear-gradient(rgba( 57, 55, 77, 0.75 ), rgba( 57, 55, 77, 0.75 )), url('web/assets/img/slide/m1.jpeg');">
        <div class="carousel-container">
          <div class="carousel-content animate__animated animate__fadeInUp">
            <h2 class="text-center"><?php echo e(__('main.title')); ?></h2>
            <p><?php echo e(__('main.title-hero')); ?>.</p>
            <div class="text-center"><a href="#idea" class="btn-get-started"><?php echo e(__('main.Read-More')); ?></a></div>
          </div>
        </div>
      </div>

    </div>


    <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>


  </div>


</section><!-- End Hero -->

<main id="main">

  <!-- ======= About Us Section ======= -->
  <!-- <section id="about-us" class="about-us">
      <div class="container" data-aos="fade-up">

        <div class="row content">
          <div class="col-lg-6" data-aos="fade-right">
            <h2>Eum ipsam laborum deleniti velitena</h2>
            <h3>Voluptatem dignissimos provident quasi corporis voluptates sit assum perenda sruen jonee trave</h3>
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0" data-aos="fade-left">
            <p>
              Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
              velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
              culpa qui officia deserunt mollit anim id est laborum
            </p>
            <ul>
              <li><i class="ri-check-double-line"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequa</li>
              <li><i class="ri-check-double-line"></i> Duis aute irure dolor in reprehenderit in voluptate velit</li>
              <li><i class="ri-check-double-line"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in</li>
            </ul>
            <p class="fst-italic">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
              magna aliqua.
            </p>
          </div>
        </div>

      </div>
    </section>End About Us Section -->

  <!-- ======= Services Section ======= -->
  <section id="services" class="services section-bg">
    <div class="container" data-aos="fade-up">

      <div class="row">
        <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
          <div class="icon-box iconbox-orange">
            <div class="icon">
              <svg width="100" height="100" viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg">
                <path stroke="none" stroke-width="0" fill="#f5f5f5" d="M300,521.0016835830174C376.1290562159157,517.8887921683347,466.0731472004068,529.7835943286574,510.70327084640275,468.03025145048787C554.3714126377745,407.6079735673963,508.03601936045806,328.9844924480964,491.2728898941984,256.3432110539036C474.5976632858925,184.082847569629,479.9380746630129,96.60480741107993,416.23090153303,58.64404602377083C348.86323505073057,18.502131276798302,261.93793281208167,40.57373210992963,193.5410806939664,78.93577620505333C130.42746243093433,114.334589627462,98.30271207620316,179.96522072025542,76.75703585869454,249.04625023123273C51.97151888228291,328.5150500222984,13.704378332031375,421.85034740162234,66.52175969318436,486.19268352777647C119.04800174914682,550.1803526380478,217.28368757567262,524.383925680826,300,521.0016835830174"></path>
              </svg>
              <i class="bx bx-tachometer"></i>
            </div>
            <h4><a href=""><?php echo e(__('main.Vision')); ?></a></h4>
            <p><?php echo e(__('main.vision-text')); ?></p>
          </div>
        </div>

        <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="zoom-in" data-aos-delay="200">
          <div class="icon-box iconbox-orange ">
            <div class="icon">
              <svg width="100" height="100" viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg">
                <path stroke="none" stroke-width="0" fill="#f5f5f5" d="M300,582.0697525312426C382.5290701553225,586.8405444964366,449.9789794690241,525.3245884688669,502.5850820975895,461.55621195738473C556.606425686781,396.0723002908107,615.8543463187945,314.28637112970534,586.6730223649479,234.56875336149918C558.9533121215079,158.8439757836574,454.9685369536778,164.00468322053177,381.49747125262974,130.76875717737553C312.15926192815925,99.40240125094834,248.97055460311594,18.661163978235184,179.8680185752513,50.54337015887873C110.5421016452524,82.52863877960104,119.82277516462835,180.83849132639028,109.12597500060166,256.43424936330496C100.08760227029461,320.3096726198365,92.17705696193138,384.0621239912766,124.79988738764834,439.7174275375508C164.83382741302287,508.01625554203684,220.96474134820875,577.5009287672846,300,582.0697525312426"></path>
              </svg>
              <i class="bx bx-file"></i>
            </div>
            <h4><a href=""><?php echo e(__('main.message')); ?></a></h4>
            <p><?php echo e(__('main.message-text')); ?></p>
          </div>
        </div>

        <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0" data-aos="zoom-in" data-aos-delay="300">
          <div class="icon-box iconbox-orange">
            <div class="icon">
              <svg width="100" height="100" viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg">
                <path stroke="none" stroke-width="0" fill="#f5f5f5" d="M300,541.5067337569781C382.14930387511276,545.0595476570109,479.8736841581634,548.3450877840088,526.4010558755058,480.5488172755941C571.5218469581645,414.80211281144784,517.5187510058486,332.0715597781072,496.52539010469104,255.14436215662573C477.37192572678356,184.95920475031193,473.57363656557914,105.61284051026155,413.0603344069578,65.22779650032875C343.27470386102294,18.654635553484475,251.2091493199835,5.337323636656869,175.0934190732945,40.62881213300186C97.87086631185822,76.43348514350839,51.98124368387456,156.15599469081315,36.44837278890362,239.84606092416172C21.716077023791087,319.22268207091537,43.775223500013084,401.1760424656574,96.891909868211,461.97329694683043C147.22146801428983,519.5804099606455,223.5754009179313,538.201503339737,300,541.5067337569781"></path>
              </svg>

              <i class="bx bxl-dribbble"></i>
            </div>
            <h4><a href=""><?php echo e(__('main.Target')); ?></a></h4>
            <p><?php echo e(__('main.Target-text')); ?></p>
          </div>
        </div>



      </div>

    </div>
  </section><!-- End Services Section -->

  <!-- ======= Portfolio Section ======= -->
  <section id="idea" class="pricing">
    <div class="container">
      <div class="section-title">
        <h2><?php echo e(__('main.idea')); ?></h2>
        <p><?php echo e(__('main.idea-text')); ?></p>
      </div>



      <div class="row">
        <div class="col-lg-3 col-md-6">
          <div class="box">
            <h3 style="color:#000"><?php echo e(__('main.course')); ?></h3>

            <ul>
              <li><?php echo e(__('main.course-text1')); ?></li>
              <li><?php echo e(__('main.course-text2')); ?></li>
              <li><?php echo e(__('main.course-text3')); ?></li>
              <li><?php echo e(__('main.course-text4')); ?></li>
            </ul>
          </div>
        </div>

        <div class="col-lg-3 col-md-6">
          <div class="box">
            <h3 style="color:#000"><?php echo e(__('main.requirements')); ?></h3>
            <ul>
              <li><?php echo e(__('main.requirements-text1')); ?></li>
              <li><?php echo e(__('main.requirements-text2')); ?></li>
              <li><?php echo e(__('main.requirements-text3')); ?></li>
              <li><?php echo e(__('main.requirements-text4')); ?></li>

              <li><?php echo e(__('main.requirements-text5')); ?></li>
            </ul>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="box">

            <h3 style="color:#000"><?php echo e(__('main.Course-curricula')); ?></h3>
            <ul>
              <li><?php echo e(__('main.Course-curricula-1')); ?></li>
              <li><?php echo e(__('main.Course-curricula-2')); ?></li>
              <li><?php echo e(__('main.Course-curricula-3')); ?></li>
              <li><?php echo e(__('main.Course-curricula-4')); ?></li>
              <li><?php echo e(__('main.Course-curricula-5')); ?></li>
              <li><?php echo e(__('main.Course-curricula-6')); ?></li>
              <li><?php echo e(__('main.Course-curricula-7')); ?></li>
            </ul>
          </div>

        </div>
        <div class="col-lg-3 col-md-6">
          <div class="box">
            <h3 style="color:#000"><?php echo e(__('main.course-start')); ?></h3>
            <ul>
              <li><?php echo e(__('main.course-start-text')); ?></li>
            </ul>
          </div>
        </div>


      </div>

    </div>

    </div>
  </section><!-- End Portfolio Section -->






  <!-- ======= Our Clients Section ======= -->
  <section id="goles" class="clients">
    <div class="container" data-aos="fade-up">

      <div class="section-title">
        <h3 style="text-align:right; font-size: 32px;
  font-weight: bold;

 "><?php echo e(__('main.Goals')); ?></h3>
      </div>

      <div class="row" data-aos="fade-up">

        <div class="col-md-6">
          <ol>
            <li><?php echo e(__('main.goles-text-1')); ?></li>
            <li><?php echo e(__('main.goles-text-2')); ?></li>
            <li><?php echo e(__('main.goles-text-3')); ?></li>
            <li><?php echo e(__('main.goles-text-4')); ?></li>
            <li><?php echo e(__('main.goles-text-5')); ?></li>
            <li><?php echo e(__('main.goles-text-6')); ?></li>
          </ol>
        </div>

        <div class="col-md-6">
          <img src="web/assets/img/slide/b.jpg" width="550px" alt="">
        </div>

      </div>



    </div>
  </section><!-- End Our Clients Section -->


  <section id="output" class="clients">
    <div class="container" data-aos="fade-up">
      <div class="row" data-aos="fade-up">
        <div class="col-md-6">
          <img src="web/assets/img/slide/b.jpg" width="550px" alt="">
        </div>

        <div class="col-md-6">
          <div class="section-title">
            <h3 style="text-align:right; font-size: 32px;
  font-weight: bold;

 "><?php echo e(__('main.output')); ?></h3>
          </div>
          <p><?php echo e(__('main.stadiy')); ?></p>
          <ol>
            <li><?php echo e(__('main.output-1')); ?></li>
            <li><?php echo e(__('main.output-2')); ?></li>
            <li><?php echo e(__('main.output-3')); ?></li>
            <li><?php echo e(__('main.output-4')); ?></li>


          </ol>
        </div>


      </div>
    </div>
  </section>


  <section id="contact" class="contact">
    <div class="container">

      <div class="row justify-content-center" data-aos="fade-up">

        <div class="col-lg-12">

          <div class="info-wrap">
            <div class="row">
              <div class="col-lg-12 info">
                <i class="bi bi-geo-alt"></i>
                <h4 class="text-center">يمكنك التواصل من خلال رسائل الوتساب أو البريد</h4><br>
                <p class="text-center">سنقوم بالرد عليك في أقرب فرصة</p><br>
                <h4 class="text-center"> 0583301643</h4><br>

                <h4 class="text-center">
                  al.dawa.shafa@gmail.com
                </h4><br>
              </div>


            </div>
          </div>

        </div>

      </div>



    </div>
  </section><!-- End Contact Section -->

</main><!-- End #main -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\freelancer project\Example-laravel9\resources\views/welcome.blade.php ENDPATH**/ ?>