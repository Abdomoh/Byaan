

<?php $__env->startSection('content'); ?>
<!-- ======= Pricing Section ======= -->
<br><br><br><br>
<section id="pricing" class="pricing">
    <div class="container" data-aos="fade-up">
        <h3>المقررات الدراسية :</h3>
        <div class="row">
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6 mt-4 mt-lg-0">
                <div class="box">
                    <h3><?php echo e($book->title); ?></h3>
                    <?php if($book->url==NULL): ?>
                    <center> <img src="web/assets/img/slide/m1.jpeg" class="rounded" width="230px" alt="البروفايل"></center>
                    <?php else: ?>
                    <center> <img src="uploads/<?php echo e($book->url); ?>" class="rounded" width="230px" alt="البروفايل"></center>
                    <?php endif; ?>
                    <br>
                    <p style="text-align: right; font-weight:bold;"> المؤلف:<?php echo e($book->other); ?></p>
                    <p style="text-align: right; font-weight:bold;">الطبعة :<?php echo e($book->edition); ?></p>

                    <div class="btn-wrap">
                        <a href="/pdf/<?php echo e($book->pdf); ?>" download="" class="btn-buy">
                            <i class="bx bxl-download"></i>تحميل الكتاب </a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <br><br>



            <div class="col-lg-3 col-md-6 mt-4 mt-lg-0">
                <div class="card">
                    <div class="card-body">
                        <?php if(auth()->guard()->check()): ?>
                        <?php if(Auth::user()->url==NULL): ?>
                        <center> <img src="web/assets\img\profile.svg" class="rounded-circle" width="200px" alt="البروفايل"></center>
                        <?php else: ?>
                        <center> <img src="uploads/<?php echo e(Auth::user()->url); ?>" class="rounded-circle" width="200px" alt="البروفايل"></center>
                        <?php endif; ?>

                        <br>
                        <h5 class="text-center" style="font-weight:bold"><?php echo e(Auth::user()->name); ?></h5>
                        <h5 class="text-center" style="font-weight:bold"><?php echo e(Auth::user()->email); ?></h5>
                        <hr>
                        <h5 class="text-center"> الاستاذ المتابع :</h5>
                        <div class="text-center"><a href="<?php echo e($zooms->url ?? ''); ?>"> <button type="submit" class="btn btn-warning btn-block text-white" value="انشاء حساب "> <i class="fa fa-plus"></i> الانضمام الي غرفة ال zoom </button></a></div>
                        <div class="btn-wrap">


                            <a class="btn-buy" href="<?php echo e(url('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                تسجيل خروج
                            </a>

                            <form id="logout-form" action="<?php echo e(url('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>

                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>




        </div>


    </div>

</section><!-- End Pricing Section -->
<div>
    <center> <?php echo $books->links(); ?></center>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\freelancer project\Example-laravel9\resources\views/admin/students/index.blade.php ENDPATH**/ ?>