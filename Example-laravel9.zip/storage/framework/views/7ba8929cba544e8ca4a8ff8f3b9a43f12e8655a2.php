
<?php $__env->startSection('css'); ?>
<?php $__env->startSection('title'); ?>
ادارة الكتب
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- row -->
<div class="row">
    <div class="col-sm-6">
        <h4 class="mb-0" style=" font-family: 'Cairo', sans-serif;">الكتب </h4>
    </div>
    <div class="col-sm-6">
        <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right ">
            <li class="breadcrumb-item"><a href="/dashboard" class="default-color">الرئسية</a></li>
            <li class="breadcrumb-item active"> الكتب</li>
        </ol>
    </div>
    <?php echo $__env->make('message._message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-xl-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">
                <h5 class="card-title">بيانات الكتاب </h5>
                <!-- add_form -->
                <form action="<?php echo e(route('books.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="repeater-add">
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="inputEmail5">عنوان الكتاب </label>
                                <input type="text" name="title" class="form-control" id="inputEmail5" value="<?php echo e(old('title')); ?>">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="inputEmail5">المؤلف</label>
                                <input type="text" name="other" class="form-control" id="inputEmail5" value="<?php echo e(old('other')); ?>">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="inputEmail5">الطبعة</label>
                                <input type="text" name="edition" class="form-control" id="inputEmail5" value="<?php echo e(old('edition')); ?>">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="inputEmail5">عدد صفحات الكتاب</label>
                                <input type="number" name="page_number" class="form-control" id="inputEmail5" value="<?php echo e(old('page_number')); ?>">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="inputEmail5">صورة الغلاف</label>
                                <input type="file" name="url" class="form-control" id="inputEmail5" value="<?php echo e(old('url')); ?>">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="inputEmail5">اضف الكتاب </label>
                                <input type="file" name="pdf" class="form-control" id="inputEmail5" value="<?php echo e(old('pdf')); ?>">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group clearfix mb-20">
                                <button type="submit" class="btn btn-info x-small" value="Add shipping Address"> <i class="fa fa-plus"></i> اضافة</button>
                                <button type="reset" class="btn btn-warning x-small" value="Add shipping Address"><i class="fa fa-share"></i>مسح </button>
                            </div>
                        </div>

                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- row closed -->

<!-- image preview -->

<!--    image end -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
@toastr_js
@toastr_render
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\freelancer project\Example-laravel9\resources\views/admin/books/create.blade.php ENDPATH**/ ?>